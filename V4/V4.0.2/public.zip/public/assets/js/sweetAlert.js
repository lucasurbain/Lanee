//Script sweetALert

function validation() {
    swal(
        'Merci !',
        'Notre équipe à reçu ton mail et va te répondre rapidement!',
        'success'
    )
};

window.onload = validation();